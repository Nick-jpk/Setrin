import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Home from './pages/Home';
import Audio from './pages/Audio';
import Video from './pages/Video';
import About from './pages/About';
import AdminLogin from './pages/AdminLogin';
import Dashboard from './pages/Dashboard';

const App = () => {
    return (
        <Router>
            <Switch>
                <Route path="/" exact component={Home} />
                <Route path="/audio" component={Audio} />
                <Route path="/video" component={Video} />
                <Route path="/about" component={About} />
                <Route path="/admin/login" component={AdminLogin} />
                <Route path="/admin/dashboard" component={Dashboard} />
            </Switch>
        </Router>
    );
};

export default App;