const express = require('express');
const router = express.Router();
const Mix = require('../models/Mix');

// POST - Upload Mix
router.post('/upload', async (req, res) => {
    const { title, description, fileUrl } = req.body;
    const newMix = new Mix({ title, description, fileUrl });
    try {
        await newMix.save();
        res.status(201).json({ message: 'Mix uploaded successfully' });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// GET - Fetch All Mixes
router.get('/', async (req, res) => {
    try {
        const mixes = await Mix.find();
        res.status(200).json(mixes);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;